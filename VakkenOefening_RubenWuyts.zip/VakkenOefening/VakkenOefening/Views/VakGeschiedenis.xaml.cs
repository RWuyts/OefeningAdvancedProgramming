namespace VakkenOefening.Views;

public partial class VakGeschiedenis : ContentPage
{
	public VakGeschiedenis()
	{
		InitializeComponent();
	}
}