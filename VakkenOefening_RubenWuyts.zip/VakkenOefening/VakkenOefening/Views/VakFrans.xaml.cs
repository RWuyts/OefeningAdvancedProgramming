namespace VakkenOefening.Views;

public partial class VakFrans : ContentPage
{
	public VakFrans()
	{
		InitializeComponent();
	}
}