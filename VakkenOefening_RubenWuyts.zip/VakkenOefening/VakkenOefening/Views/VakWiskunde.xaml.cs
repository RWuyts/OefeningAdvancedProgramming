namespace VakkenOefening.Views;

public partial class VakWiskunde : ContentPage
{
	public VakWiskunde()
	{
		InitializeComponent();
	}
}