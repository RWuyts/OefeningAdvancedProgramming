namespace VakkenOefening.Views;

public partial class test : ContentPage
{
	public test()
	{
		InitializeComponent();
	}
}