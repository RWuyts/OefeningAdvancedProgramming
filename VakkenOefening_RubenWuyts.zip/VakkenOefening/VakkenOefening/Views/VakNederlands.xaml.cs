namespace VakkenOefening.Views;

public partial class VakNederlands : ContentPage
{
	public VakNederlands()
	{
		InitializeComponent();
	}
}