namespace VakkenOefening.Views;

public partial class VakBiologie : ContentPage
{
	public VakBiologie()
	{
		InitializeComponent();
	}
}